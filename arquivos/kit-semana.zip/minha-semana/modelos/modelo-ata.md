# ATA DE REUNIÃO · [nome da reunião]

**Vértice Distribuidora** · [projeto]
**Data:** [dd/mm/aaaa] · **Horário:** [hh:mm] · **Local:** [sala ou Teams]

## Participantes

| Participante | Função | Área |
|---|---|---|
| | | |

## Pauta

1. [tema]

## Síntese das discussões

**[Tema curto]**
- [o que foi dito, em 2 a 4 bullets por tema]

## Decisões

| Nº | Decisão |
|---|---|
| | [só o que a sala fechou] |

## Riscos identificados

| Risco | Impacto | Resposta proposta |
|---|---|---|
| | | |

## Encaminhamentos

| Ação | Responsável | Prazo |
|---|---|---|
| | | [dd/mm ou "a definir"] |

---
*Fonte: transcrição automática da reunião de [dd/mm/aaaa]. Ata preparada por [nome] e aprovada por [nome] em [dd/mm/aaaa].*
