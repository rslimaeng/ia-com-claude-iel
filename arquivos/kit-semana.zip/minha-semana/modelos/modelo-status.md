# STATUS REPORT SEMANAL · [projeto]

**Vértice Distribuidora** · para a diretoria
**Semana:** [dd/mm a dd/mm/aaaa] · **Preparado por:** [nome] · **Responsável pelo projeto:** [nome]

## Em uma linha

**Farol:** [verde · amarelo · vermelho] · [o estado real do projeto em uma frase: o que andou ou o que travou]

## O que andou na semana

- [entrega ou decisão, com a ata ou o arquivo de onde veio]

## Em andamento

| Frente | Situação | Responsável | Prazo |
|---|---|---|---|
| | | | |

## Riscos e pontos de atenção

| Risco | O que ele trava | Impacto | Resposta proposta |
|---|---|---|---|
| | | | |

## Decisões que precisamos da diretoria

| Decisão | Opções | Impacto de cada opção | Até quando |
|---|---|---|---|
| | | | |

## Próximos passos

| Ação | Responsável | Prazo | De onde veio |
|---|---|---|---|
| | | | |

---
*Fontes: atas aprovadas da semana, registro de decisões e arquivos recebidos. O que não foi definido em reunião aparece como "não definido".*
